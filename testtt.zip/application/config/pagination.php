<?php
$config['per_page'] = 10;
$config['full_tag_open']    = '<div><ul class="pagination">';
$config['full_tag_close']   = '</ul></div>';
$config['first_link']       = '<li class="page-item page-link">Awal</li>';
$config['last_link']        = '<li class="page-item page-link">Akhir</li>';
$config['prev_link']        = '&laquo';
$config['prev_tag_open']    = '<li class="page-item page-link">';
$config['prev_tag_close']   = '</li>';
$config['next_link']        = '&raquo';
$config['next_tag_open']    = '<li class="page-item page-link">';
$config['next_tag_close']   = '</li>';
$config['cur_tag_open']     = '<li class="page-item page-link">';
$config['cur_tag_close']    = '</li>';
$config['num_tag_open']     = '<li class="page-item page-link">';
$config['num_tag_close']    = '</li>';
